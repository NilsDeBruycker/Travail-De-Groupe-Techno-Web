jon a pour mot de passe 1234 est normal et posede 2-3 livres
joseph a pour mot de passe 4321 email=joseph@gmail.com est admin
that guy a à pour email realAmaz0n pour mot de passe 8765 et est blocké et normal