-- SQLite
CREATE TABLE USERS( id_book char(1) not null,
     prix char(1) not null,
     Nom char(1) not null,
     Status char(1) not null,
     Email char(1) not null,
     constraint ID_book_ID primary key (id_book));
