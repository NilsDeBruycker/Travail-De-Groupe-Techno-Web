Bienvenue sur notre application de librairie ses fonctions sont get all books qui vas montrer tous les livres stockés dans la bibliothèque. modify book qui modifie un livre et delete book qui en supprime un tous deux grâce à l’id du livre.
routes
get all books :get, car récupère info 
modify book :post, car modifie des informations dans la DB du site
delete book :delete, car supprime info dans la DB du site
new book :post, car, car créé des informations dans la DB du site
